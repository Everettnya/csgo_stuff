static int nativePush=0,nativePop=0,nativeText=0,nativeLines=0;static bool nativeEb=false,nativePx=false;static void* schemeObject;
static void paintOriginal(void*,uintptr_t,bool,bool){}static const char*panelName(void*,uintptr_t){return "MatSystemTopPanel";}
static unsigned defaultScheme(void*){return 1;}static void* getScheme(void*,unsigned){return schemeObject;}static uintptr_t getFont(void*,const char*,bool){return 7;}
static void screenSize(void*,int&w,int&h){w=800;h=600;}
static void pushNative(void*,uintptr_t,bool){nativePush++;}static void popNative(void*,uintptr_t){nativePop++;}
static void setNativeColor(void*,int,int,int,int){}static void nativeLine(void*,int,int,int,int){nativeLines++;}static void setFont(void*,uintptr_t){}static void setTextPos(void*,int,int){}
static void printNative(void*,const wchar_t*s,int,int){nativeText++;if(!wcscmp(s,L"eb"))nativeEb=true;if(!wcscmp(s,L"px"))nativePx=true;}
static void flushNative(void*){}static void nativeTextSize(void*,uintptr_t,const wchar_t*s,int&w,int&h){w=int(wcslen(s))*6;h=12;}
static void testNativeHUD(){
 void*pv[43]{};pv[37]=(void*)&panelName;void**pp=pv;void*sv[80]{};sv[12]=(void*)&pushNative;sv[13]=(void*)&popNative;sv[14]=(void*)&setNativeColor;sv[19]=(void*)&nativeLine;sv[23]=(void*)&setFont;sv[24]=(void*)&setNativeColor;sv[26]=(void*)&setTextPos;sv[28]=(void*)&printNative;sv[30]=(void*)&flushNative;sv[79]=(void*)&nativeTextSize;void**sp=sv;
 void*mv[10]{};mv[5]=(void*)&defaultScheme;mv[9]=(void*)&getScheme;void**mp=mv;void*fv[5]{};fv[4]=(void*)&getFont;void**fp=fv;schemeObject=&fp;
 nativeSurface=&sp;nativeSchemes=&mp;originalPaint=paintOriginal;(*reinterpret_cast<void***>(engine))[5]=(void*)&screenSize;snap.frame=3;snap.speed=123;snap.ebHold=true;snap.ebLocal=false;snap.eb=false;snap.pxLocal=true;hud=true;nativePaint(&pp,1,false,true);
 assert(nativePush==1&&nativePop==1&&nativeText==4&&nativeLines==3&&nativeEb&&nativePx&&nativeActive());
}
