#include "movement.cpp"
#include <cassert>
using namespace mint;
static unsigned char player[256];static unsigned char foe[256];static bool exposeFoe=false,dormantFoe=false;
static Vec lastView;static int viewCalls=0;static void setView(void*,const Vec&v){lastView=v;viewCalls++;}
static int vertices=0;static void vertex(float x,float y){assert(std::isfinite(x)&&std::isfinite(y));vertices++;}
static Matrix testMatrix;static void** networkVptr;
static void* network(void*){return &networkVptr;}static bool dormant(void*){return dormantFoe;}
static const Matrix& matrix(void*){return testMatrix;}static bool info(void*,int,void*p){strcpy((char*)p+16,"Test Enemy");return true;}
static bool wrongDormantSlot(void*){assert(false&&"slot 8 must never be called for dormancy");return true;}
static bool inGame(void*){return true;}static int local(void*){return 1;}static void* entity(void*,int i){return i==1?player:i==2&&exposeFoe?foe:nullptr;}static bool moveOriginal(void*,float,Cmd*){return true;}
static bool wallScene=false,floorScene=false;
static void clearTrace(void*,const Ray&r,unsigned,Filter*,Trace*t){
 *t={};t->fraction=1;t->start={r.start.x+r.offset.x,r.start.y+r.offset.y,r.start.z+r.offset.z};Vec delta{r.delta.x,r.delta.y,r.delta.z};t->end=t->start+delta;
 auto hit=[&](float f,Vec n){if(f>=0&&f<t->fraction){t->fraction=f;t->plane.normal=n;t->end=t->start+delta*f;}};
 if(wallScene&&delta.x>0)hit((17-r.extents.x-r.start.x)/delta.x,{-1,0,0});
 if(floorScene&&delta.z<0&&t->start.z>=0){float f=-t->start.z/delta.z;if(t->start.x+delta.x*f<0)hit(f,{0,0,1});}
}
static float nativeInputZ=0;
static void nativeProcess(void*,void*,void*data){Vec v=get<Vec>(data,64);nativeInputZ=v.z;v.z-=gravity*dt;memcpy((char*)data+64,&v,sizeof v);}
template<class T>static void put(int offset,T v){memcpy(player+offset,&v,sizeof v);}
#include "native_tests.inc"
int main(){
 assert(!activationEnabled(nullptr)&&!activationEnabled("0")&&!activationEnabled("true")&&activationEnabled("1"));
 Prop props[2]{};props[0].name="m_test";props[0].offset=16;Table inner{props,1,nullptr,"inner",true,true};Prop outer{};outer.name="nested";outer.offset=32;outer.table=&inner;Table root{&outer,1,nullptr,"root",true,true};assert(findprop(&root,"m_test")==48);assert(findprop(&root,"missing")==-1);
 void*ev[38]{};ev[19]=(void*)&setView;ev[8]=(void*)&info;ev[37]=(void*)&matrix;ev[12]=(void*)&local;ev[26]=(void*)&inGame;void** ep=ev;engine=&ep;void*lv[4]{};lv[3]=(void*)&entity;void**lp=lv;entities=&lp;
 void*tv[6]{};tv[5]=(void*)&clearTrace;void**tp=tv;trace=&tp;
 flagsOff=0;healthOff=4;velOff=8;originOff=20;minsOff=32;maxsOff=44;waterOff=56;
 put<int>(0,0);put<int>(4,100);put<Vec>(8,{300,400,-100});put<Vec>(20,{0,0,100});put<Vec>(32,{-16,-16,0});put<Vec>(44,{16,16,72});put<unsigned char>(56,0);
 original=&moveOriginal;initialized=true;Cmd c{};c.number=1;c.buttons=2;assert(createMove(nullptr,dt,&c));assert(!(c.buttons&2));assert(fabsf(snap.speed-500)<.01f);
 put<int>(0,1);c.number++;c.buttons=2;createMove(nullptr,dt,&c);assert(c.buttons&2);
 put<int>(0,0);put<unsigned char>(56,2);c.number++;c.buttons=2;createMove(nullptr,dt,&c);assert(c.buttons&2);
 auto o=forecast(player,{0,0,100},{100,0,-100},{-16,-16,0},{16,16,72},c,false,1,true);assert(!o.eb&&!o.px);
 assert(!expected("/dev/null"));

 // Pure policy: contact required, no rising/grounded overrides, edge latch.
 Contact wall;wall.wall=true;wall.normal={-1,0,0};
 auto px=chooseOverride(wall,{20,80,-200},true,false,true,false);assert(px.px&&px.velocity.z==-config.pxFall&&px.velocity.x==0&&px.velocity.y==80);
 assert(!chooseOverride(wall,{20,80,100},true,false,true,false).px);
 assert(!chooseOverride(wall,{20,80,-200},false,false,true,false).px);
 Contact edge;edge.edge=true;assert(chooseOverride(edge,{20,80,-200},true,true,false,false).eb);
 assert(!chooseOverride(edge,{20,80,-200},true,true,false,true).eb);
 assert(!chooseOverride({}, {20,80,-200},true,true,true,false).eb);
 assert(parseBind("scancode:4").code==4);assert(parseBind("scancode:512").code==-1);assert(parseBind("Mouse4").mouse&&parseBind("Mouse4").code==4);assert(parseBind("None").code==-1);
 configPath="/tmp/mint-linux-test-"+std::to_string(getpid())+".ini";
 {std::ofstream cfg(configPath);cfg<<"eb_key = scancode:4\npx_key = Mouse4\nlocal_physics = 0\npx_fall_speed = 2.5\npx_wall_range = nan\n";}
 loadConfig();assert(ebBind.code==4&&pxBind.mouse&&pxBind.code==4);assert(!config.local&&config.pxFall==2.5f&&config.wallRange==4);remove(configPath.c_str());config=Config{};localMode=true;
 // Full mock ProcessMovement callback, before/after-native enforcement.
 alignas(16) unsigned char data[256]{};auto mdvel=[&](Vec v){memcpy(data+64,&v,sizeof v);};
 originalProcess=nativeProcess;put<unsigned char>(56,0);put<int>(0,0);put<Vec>(20,{0,0,100});wallScene=true;wantPX=true;wantEB=false;mdvel({100,80,-200});processMovement(nullptr,player,data);assert(nativeInputZ==-6.25f&&get<Vec>(data,64).z==-6.25f);
 wantPX=false;wantEB=true;wallScene=false;floorScene=true;put<Vec>(20,{-4,0,6});mdvel({100,0,-200});processMovement(nullptr,player,data);assert(nativeInputZ==-gravity*dt*.5f&&get<Vec>(data,64).z==-gravity*dt*.5f);
 mdvel({100,0,-200});processMovement(nullptr,player,data);assert(nativeInputZ==-200); // same edge latched
 wantEB=false;processMovement(nullptr,player,data);wantEB=true;mdvel({100,0,-200});processMovement(nullptr,player,data);assert(nativeInputZ==-gravity*dt*.5f); // release rearms
 put<unsigned char>(56,2);mdvel({100,0,-200});processMovement(nullptr,player,data);assert(nativeInputZ==-200); // no override in water

 Matrix identity{};for(int i=0;i<4;i++)identity.m[i][i]=1;float sx,sy;assert(project({0,0,0},identity,800,600,sx,sy)&&sx==400&&sy==300);Matrix behind=identity;behind.m[3][3]=-1;assert(!project({0,0,0},behind,800,600,sx,sy));
 EnemyWorld unit;for(int i=0;i<8;i++)unit.corner[i]={i&1?.5f:-.5f,i&2?.5f:-.5f,0};ScreenBox box;assert(projectBox(unit,identity,800,600,box));assert(box.left==200&&box.right==600&&box.top==150&&box.bottom==450);
 char cleaned[33];cleanName(cleaned,(const unsigned char*)"Test Enemy",11);assert(!strcmp(cleaned,"Test Enemy"));cleanName(cleaned,(const unsigned char*)"",1);assert(!strcmp(cleaned,"PLAYER"));
 void*entityVt[6]{};entityVt[5]=(void*)&network;void**entityVp=entityVt;memcpy(foe,&entityVp,8);void*nv[10]{};nv[8]=(void*)&wrongDormantSlot;nv[9]=(void*)&dormant;networkVptr=nv;
 teamOff=100;lifeOff=104;healthOff=84;put<int>(100,2);int team=3,hp=75;memcpy(foe+100,&team,4);memcpy(foe+84,&hp,4);Vec org{0,0,0},mi{-16,-16,0},ma{16,16,72};memcpy(foe+20,&org,12);memcpy(foe+32,&mi,12);memcpy(foe+44,&ma,12);testMatrix=identity;exposeFoe=true;enemyOverlay=true;
 collectEnemies(player);assert(enemyFrame.count==1&&enemyFrame.players[0].health==75&&!strcmp(enemyFrame.players[0].name,"Test Enemy"));dormantFoe=true;collectEnemies(player);assert(enemyFrame.count==0);dormantFoe=false;team=2;memcpy(foe+100,&team,4);collectEnemies(player);assert(enemyFrame.count==0);team=3;memcpy(foe+100,&team,4);foe[104]=1;collectEnemies(player);assert(enemyFrame.count==0);

 // Near-camera AABB crossing the near plane must not vanish.
 EnemyWorld crossing;for(int i=0;i<8;i++)crossing.corner[i]={i&1?1.f:-1.f,i&2?1.f:-1.f,i&4?1.f:-1.f};Matrix perspective=identity;perspective.m[3][3]=0;perspective.m[3][2]=1;
 assert(projectBox(crossing,perspective,800,600,box));assert(box.left>=0&&box.right<=799&&box.top>=0&&box.bottom<=599);
 Matrix far=identity;far.m[3][3]=1e7f;assert(projectBox(unit,far,800,600,box));assert(box.right-box.left>=3&&box.bottom-box.top>=5);
 assert(!projectBox(unit,behind,800,600,box));Matrix off=identity;off.m[0][3]=100;assert(!projectBox(unit,off,800,600,box));
 gl.vertex=vertex;vertices=0;line(0,0,30,40,1);assert(vertices==4);line(0,0,0,0,1);assert(vertices==4);vertices=0;stick({100,100,200,300});assert(vertices==84);

 Vec aim;assert(chooseAimPoint(true,true,{1,2,3},{4,5,6},aim)&&aim.z==3);assert(chooseAimPoint(false,true,{1,2,3},{4,5,6},aim)&&aim.z==6);assert(!chooseAimPoint(false,false,{1,2,3},{4,5,6},aim));
 floorScene=false;wallScene=true;assert(!pointVisible(player,foe,{0,0,100},{50,0,100}));wallScene=false;assert(pointVisible(player,foe,{0,0,100},{50,0,100}));
 EnemyFrame candidates;candidates.count=3;candidates.players[0].canAim=true;candidates.players[0].distance2=100;candidates.players[1].canAim=false;candidates.players[1].distance2=1;candidates.players[2].canAim=true;candidates.players[2].distance2=25;assert(nearestVisible(candidates)==2);
 put<int>(84,100);put<Vec>(20,{0,0,0});put<Vec>(44,{16,16,72});candidates.players[2].aimPoint={0,10,64};candidates.updated=nowSeconds();enemyFrame=candidates;config.aimLead=0;config.aimEyeLead=0;wantAim=true;Cmd aimed{};aimed.forward=100;aimAtVisible(player,aimed);assert(viewCalls==1&&fabsf(lastView.y-90)<.01f&&fabsf(aimed.forward)<.01f&&fabsf(aimed.side-100)<.01f);wantAim=false;aimAtVisible(player,aimed);assert(viewCalls==1);wantAim=true;enemyFrame.updated=nowSeconds()-1;aimAtVisible(player,aimed);assert(viewCalls==1);

 unsigned char header[1024]{};auto setint=[&](int o,int n){memcpy(header+o,&n,4);};setint(0,0x54534449);setint(76,1024);setint(156,2);setint(172,1);setint(176,192);setint(196,2);setint(200,12);setint(204,0);setint(208,1);setint(272,1);setint(276,2);Vec lo{-2,-2,-2},hi{2,2,2};memcpy(header+212,&lo,12);memcpy(header+224,&hi,12);memcpy(header+280,&lo,12);memcpy(header+292,&hi,12);
 BoneMatrix bones[256]{};for(int i=0;i<2;i++)for(int j=0;j<3;j++)bones[i].m[j][j]=1;bones[0].m[0][3]=100;bones[0].m[2][3]=70;bones[1].m[0][3]=100;bones[1].m[2][3]=40;Vec head,body;assert(hitboxCenters(header,0,bones,head,body)&&head.x==100&&head.z==70&&body.z==40);assert(!hitboxCenters(header,1,bones,head,body));setint(208,0);assert(!hitboxCenters(header,0,bones,head,body));setint(208,1);setint(204,999);assert(!hitboxCenters(header,0,bones,head,body));
 auto white=indicator(true,false,false),green=indicator(true,true,false),purple=indicator(true,true,true);assert(white.show&&white.r==255&&white.g==255&&white.b==255);assert(green.g>green.r);assert(purple.b>purple.g&&purple.r>purple.g);assert(!indicator(false,false,false).show);

 // v6.1 integration regression: missing model data must not disable fallback aim.
 config.aimFallback=true;config.aimLead=0;config.aimEyeLead=0;modelInfo=nullptr;foe[104]=0;Vec targetOrigin{100,0,0};memcpy(foe+20,&targetOrigin,12);wallScene=false;floorScene=false;wantAim=true;int before=viewCalls;collectEnemies(player);assert(enemyFrame.count==1&&enemyFrame.players[0].canAim&&!enemyFrame.players[0].precise&&enemyFrame.approximate==1);aimAtVisible(player,aimed);assert(viewCalls==before+1);
 config.aimFallback=false;collectEnemies(player);assert(enemyFrame.count==1&&!enemyFrame.players[0].canAim);aimAtVisible(player,aimed);assert(viewCalls==before+1);
 config.aimFallback=true;wallScene=true;collectEnemies(player);assert(enemyFrame.count==1&&enemyFrame.players[0].blocked&&!enemyFrame.players[0].canAim);aimAtVisible(player,aimed);assert(viewCalls==before+1);wallScene=false;
 testNativeHUD();
 puts("PASS: prior regressions; animated bone-space hitbox centers; invalid model/set/bone rejection; lowercase indicator priority/colors; small HUD build; motion lead configurable; v6.1 unavailable-model fallback restores aiming; strict mode and wall exclusion retained.");
}
