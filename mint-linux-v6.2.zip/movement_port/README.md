# v6.2 — no -insecure launch requirement

Removed only the module's command-line check for -insecure. Activation still requires MINT_ENABLE=1. Existing client-build checks remain, and HUD, aim, configuration, visibility, and movement behavior are unchanged from v6.1.

## Install / launch

Exit the game fully and replace libmint_linux.so. Launch options can now be:

```sh
MINT_ENABLE=1 LD_PRELOAD=/absolute/path/libmint_linux.so %command%
```

You may still use -insecure if you want it. The library no longer requires it.

**This change does not disable, bypass, conceal the module from, or provide protection against VAC or any other anti-cheat. Loading it may lead to penalties. Use only offline or on servers that explicitly permit it.** No anti-cheat mechanisms were modified.

The previous v6.1 library, which requires -insecure, is included as release/libmint_linux-v6.1.so. Do not load both together.

Validation: ASan/UBSan regression suite passes; activation tests cover unset/0/true/1; disabled preload exits cleanly; enabled preload without -insecure enters module initialization. This is not a live CS:GO compatibility test or an anti-cheat safety test.

**Release notes below describe older versions. Their -insecure requirements are historical and do not apply to v6.2.**

---

# v6.1 — restore aiming when animated model data is unavailable

v6 introduced a strict gate: enemies were excluded from aim whenever animated hitbox extraction failed. That is a confirmed failure path in the code, although the user's live extraction failure has not yet been diagnosed from logs.

This version restores **visible-target approximate fallback**, enabled by default. Animated centers are still preferred when available. Without them, the previous collision-bound head/torso estimate is used, so targeting can function again but does **not** gain guaranteed precise head tracking. Both paths still require line-of-sight; no hidden target aiming was added.

Default target/local velocity lead is now zero to preserve the earlier working baseline. Existing explicit config values are respected. Recommended settings for this test:

```ini
aim_key = Mouse4
aim_enabled = 1
aim_allow_approximate = 1
aim_lead_ticks = 0
aim_eye_lead_ticks = 0
```

Close the game, replace the .so, restart, and press F9 after editing the config. Set aim_allow_approximate=0 only if you intentionally want strict animated-target-only behavior.

## Diagnostics

With esp_debug=1, BONES is the number of enemies with validated animated data and APPROX is the number of visible approximate fallback candidates. Stderr logs which aim path is active and, when no target can be selected while held, reports counts and the last model-stage failure every five seconds. Examples:

- `Aim active: approximate fallback; studio header rejected`
- `Aim active: animated hitbox centers.`
- `Aim held: no visible eligible target ... SetupBones failed`

If aim remains inactive, send these lines and a screenshot of the diagnostics while holding Mouse4 and looking at an opposing-team player. They are needed to diagnose the live model/visibility/binding failure rather than guessing. Native HUD and lowercase color indicators are unchanged.

ASan/UBSan tests explicitly cover the regression: model info unavailable -> a visible fallback enemy is selected and SetViewAngles is called; strict mode still excludes it; a wall still prevents selection. v6.1 has not been run in CS:GO here. Approximate tracking accuracy and live animated model compatibility remain unresolved.

---

# v6 — native-font HUD, colored indicators, animated hitbox aim

## HUD

- Uses the game's VGUI scheme **DefaultSmall** font (Default as a fallback), not an external font. Speed and `u/s` are smaller than v5.
- Retains the thin white speed-history graph.
- Restores lowercase `eb` and `px` below the graph.
- **White** = held; **green** = non-local movement signal detected; **purple** = local override ran recently. Purple takes priority over green, then white. Inactive indicators are hidden.
- Local overrides suppress natural-event detection for 64 ticks afterward to avoid immediately relabeling synthetic movement as green. Purple persists approximately 32 ticks after an override.

**Green remains a velocity/ground-state heuristic, not server verification of an actual EB/PX.** Physics and server-correction limitations remain unchanged.

Native text hooks VGUI_Panel009::PaintTraverse at the MatSystemTopPanel. It uses PushMakeCurrent/PopMakeCurrent and the existing game font. If the native interfaces, matching function addresses, panel, or font are unavailable, the OpenGL overlay uses a smaller bitmap fallback instead of losing the HUD. Check stderr for:

- `Native HUD PaintTraverse hook installed.`
- `Native game scheme font active (DefaultSmall/Default).`

## Aim changes

Replaced estimated collision-box head positions with **animated model hitbox centers**, transformed using SetupBones. Head hitgroup is preferred; chest/stomach is the fallback. This follows head offsets in animation rather than assuming the head stays directly above the collision-box center.

- Nearest visible enemy selection, Mouse4 hold bind, and wall exclusion remain.
- Visibility is checked again using the current selected position; torso is retried if the selected point is blocked.
- A small configurable eye-position prediction compensates for the local player's movement before the next movement step.
- Target extrapolation is optional and **off by default** so the default uses the animated hitbox location rather than intentionally leading it.
- If the model/hitbox layout cannot be validated or SetupBones fails, that enemy is **not aim-selected**. It does not silently revert to the inaccurate box estimate. Overlay boxes can still appear.

Example config (F9 reload):

```ini
aim_key = Mouse4
aim_enabled = 1
aim_lead_ticks = 0
aim_eye_lead_ticks = 1
esp_debug = 0
```

Both lead values accept 0–2 ticks. If motion compensation feels ahead/behind, try `aim_eye_lead_ticks = 0` before enabling target lead. Tick duration defaults to 64 tick; set MINT_TICKRATE to match your practice server.

With `esp_debug = 1`, **BONES** reports how many active enemies had validated animated head/torso data. `Animated head/chest hitbox targeting active.` is logged on the first successful extraction. If boxes work but aim never engages, send the diagnostic line and terminal logs.

This is not a promise of perfect tracking: animation/interpolation timing, latency, camera effects/recoil, and game behavior can still cause offsets. No recoil compensation or firing automation was added. Visibility remains geometry/entity tracing, not smoke/flash interpretation.

## Install

Exit the game fully; replace libmint_linux.so; retain your working LD_PRELOAD launch options and -insecure. No config changes are required unless you want different keys/lead settings. The previous build is `release/libmint_linux-v5.1.so`.

VGUI libraries are the files supplied in the updated repository. Their source paths/architecture have been checked, and expected interface function addresses are validated before installing the native text hook. All supplied game binaries remain unchanged.

## Validation

Built successfully and passed ASan/UBSan mocked regression tests, including animated bone-transform hitbox centers, bad model/set/bone rejection, indicator color precedence, native scheme font lookup, lowercase text calls, native drawing-context balance, and previous tests. Native font/bone extraction paths have been inspected against the supplied binaries, but **v6 has not been run in CS:GO here**. Test locally first; use only offline or on a server you control that permits it.

---

# v5.1 — reference-style stick figure

Replaced the round-headed stick figure with a thinner white, angular illustration inspired by the supplied reference: small angular head, neck/spine, shoulder and hip joints, bent elbows, knees, and feet. Uses 21 one-pixel line segments.

This remains a fixed box-relative illustration. It does not follow real limbs, weapon orientation, or animation and is not an actual bone skeleton. It still appears only when both head/torso visibility probes are blocked. HUD, boxes, snaplines, binds, aiming, and movement behavior are unchanged from v5.

Exit the game fully, replace libmint_linux.so, and restart with the same launch options. No new config entries. The prior build is saved as release/libmint_linux-v5.so.

ASan/UBSan regression tests pass, including finite geometry for 21 segments (84 quad vertices). Native-game v5.1 rendering has not been tested here.

---

# v5 — minimal white HUD, occluded stick figures, hold-to-aim

## New behavior

- Minimal white movement HUD: current speed, `u/s` label, and a thin white speed-history line. No panel background, vertical speed, or movement status labels.
- Simpler stick figure (head, straight torso, two arms, two legs). It draws **only when both the head-region and torso visibility probes are blocked**. Boxes/names/health bars and snaplines remain unchanged.
- **Hold Mouse4** to turn the camera toward the closest **visible** enemy by world-space distance. Prefers a clear head-region aim point; uses the torso when the head region is blocked; does not select enemies when both points are blocked. Releasing the key stops aim adjustment. Does not shoot automatically.
- Aim selection operates independently of the F10 overlay toggle. No smoothing/FOV restriction is applied: holding can cause an immediate camera turn.

### Important accuracy details

The stick figure is still illustrative, not animated bones. Head/torso aim points are **estimated from the player's collision bounds**, not actual model hitboxes/bones, so exact head alignment is not guaranteed (especially during unusual animations). Visibility uses engine line traces against geometry/entities; it does not interpret smoke/flash effects, and two probe points are not a complete per-pixel visibility test. Other entities blocking a line also count as occlusion.

## Install and configure

Close the game and replace the active `libmint_linux.so`. Keep your working launch options and `-insecure` requirement. Use only offline or on a server you control that permits these tools.

Edit `~/.config/mint-linux.ini` (or MINT_CONFIG path), then press F9 / your reload bind:

```ini
aim_key = Mouse4
aim_enabled = 1
esp_stick_figure = 1
esp_snaplines = 1
esp_debug = 0
```

`esp_debug = 0` gives the clean HUD. Existing configs from previous versions may still have it set to 1; change it explicitly. New configs default to 0. Aim can be disabled with `aim_enabled = 0` or `aim_key = None`. F8 still controls only movement assists, not aiming. Existing game binds on Mouse4 are not suppressed.

The camera adjustment changes both user-command angles and visible camera angles and rotates forward/side movement to preserve intended movement direction. It does not alter server physics or make a hidden target visible.

The previous build is included as `release/libmint_linux-v4.so` for rollback. Existing local physics caveats and rendering/runtime requirements below still apply.

Validation: ASan/UBSan mock tests pass for head preference, torso fallback, fully blocked exclusion, nearest visible selection, held/released behavior, stale-snapshot rejection, visibility traces, movement-direction preservation, and prior regression tests. v5 has not been run in a live game here.

---

# v4 — near/far projection, snaplines, stick figures

- Removed projected-size rejection: distant enemies receive a minimum 3-by-5-pixel box.
- Removed the oversized-box rejection: close boxes are clipped to the screen instead.
- Clips the 12 world bounding-box edges against the camera near plane. A single corner behind the near plane no longer makes the entire box disappear.
- Adds cyan snaplines from the bottom-center of the screen to the bottom-center of each box.
- Adds a simple white stick figure inside each box: head, torso, arms, and legs. **This is a box-relative illustration, not actual model bones or animation.**
- Existing enemy names, right-side health bars, F10 toggle, diagnostics, and local movement tools remain.

There is no world-distance cutoff in the overlay. Entities must still be on-screen (at least partially), alive, opposing-team, non-dormant, and present in current client data. No client overlay can provide accurate current positions for entities the server no longer transmits. If boxes still vanish with distance and DORM rises, that is not fixed by projection changes; the overlay intentionally does not draw stale locations as current enemies. Fully behind-camera/off-screen enemies do not get boxes or snaplines in this version.

### Install / configure

Close the game, replace `libmint_linux.so`, and keep the existing working launch options. Both additions are on by default, including for existing configs.

```ini
esp_snaplines = 1
esp_stick_figure = 1
```

Set either to `0` to disable it and press F9 (or your assigned reload key). F10 still toggles the entire enemy overlay. `esp_debug = 0` hides the diagnostic line. The `-insecure` requirement remains.

Rollback: `release/libmint_linux-v3.1.so` is the prior working enemy-overlay build.

Validation: ASan/UBSan mock tests pass for near-plane-crossing boxes, extremely distant minimum-size targets, behind-camera/offscreen rejection, finite snapline/stick geometry, and previous regression tests. Actual v4 rendering has not been tested inside CS:GO here.

---

# v3.1 — enemy overlay fix

Fixed a real vtable mismatch in v3: IClientNetworkable::IsDormant is **slot 9** in the uploaded client, not slot 8. The previous call invoked a different entity-update function and then interpreted its return register as a boolean. That could wrongly suppress boxes and cause other entity-side effects. Restart the game when replacing v3.

Verified disassembly: C_CSPlayer networkable vtable `0x21c8b30`, slot 9 `0x7bbf30` adjusts `this` by -16 and jumps to `0x7bbf00`, which reads the dormancy flag at entity offset `0x125`. Slot 10 returns the entity index at `0x94`. A regression test deliberately fails if the dormant check uses slot 8 again.

Added a top-left diagnostic line, on by default:

`ESP ON TEAM 2 SEEN 5 ENEMY 3 DORM 0 DRAW 2`

- TEAM: local team (2 = T, 3 = CT; spectator team is not selected for enemy filtering).
- SEEN: other player-slot entities present on the client.
- ENEMY: living opposing-team entities before dormancy/geometry filtering.
- DORM: enemies excluded by the dormant check.
- DRAW: boxes passing projection and viewport checks in this render frame.

Press F10 if the line says ESP OFF. Look at an opposing-team player or bot. If no boxes appear, send a screenshot showing this line. To hide diagnostics, add `esp_debug = 0` to your config and press F9. Boxes remain independently controlled by F10 / esp_key.

Enemy collection now also continues while the local T/CT player is dead, when valid CreateMove callbacks are available. The view matrix/player-info calls still need real-game validation; the fix and diagnostics are tested here only against mocks and binary disassembly.

---

# Mint-inspired Linux v3 — enemy overlay

## New in v3

- Red outlined boxes around living enemies, using their collision bounds.
- Names centered above each box, with a dark shadow.
- Vertical health bar **on the right**, filling bottom-up and transitioning red to green.
- Teammates, dead players, and dormant entities are excluded.
- **F10** toggles the enemy overlay independently of F6's movement HUD.
- Change `esp_key = F10` in `~/.config/mint-linux.ini`; press F9 (or your configured reload key) to reload. Existing configs without this entry default to F10.

Install by closing the game and replacing the active `libmint_linux.so`. Keep the same launch options and `-insecure` requirement. No additional game binaries are required.

The small bitmap font displays ASCII letters as uppercase; unsupported/Unicode characters become `?`. Very close entities crossing the camera plane are skipped instead of drawing malformed boxes. Overlay data expires after 0.3 seconds without updates, and collection currently requires a living local player on T/CT. This reads existing client entity data only; it does not bypass server entity culling or reveal dormant entities. There is no visibility/line-of-sight filter in this version, so boxes can draw over walls when enemy data is available.

**Validation:** built successfully; ASan/UBSan mock tests pass for world-to-screen projection, behind-camera rejection, bounding boxes, player names, and enemy/team/dead/dormant filtering, plus previous regressions. v3 has not been tested in the game here. Keep v2 for rollback if necessary (`release/libmint_linux-v2.so`). The existing local-movement limitations below remain unchanged.

---

# Mint-inspired Linux v2 — local synthetic movement

This is a new implementation, **not recovered Mint source**. Mint's original assist algorithms have not been fully reverse-engineered. This version deliberately adds local synthetic physics to the previously working HUD/bunnyhop module.

## Changes in v2

- **Local PX-style wall-surf:** while holding PX and falling beside a flat wall, the module clamps local downward velocity (default 6.25 units/sec), preserves wall-tangent speed, and biases local movement input toward the wall. It does not require a genuine pixelsurf seam.
- **Local EB-style edge-save:** while holding EB and falling toward a ledge, probes look for ground beneath only part of the player's footprint. The module resets local fall speed to half a gravity tick. It need not be a naturally valid edgebug.
- **Local movement-step hook:** the velocity overrides are applied before and after the client's native ProcessMovement call, rather than relying on an approximate input forecast.
- **Configurable keyboard/mouse binds** and live config reload (F9 by default).
- Original HUD, velocity graph, bunnyhop and optional input-only mode remain.

**Important:** these changes affect client prediction only. They cannot force the server to accept the resulting motion, prevent authoritative fall damage, or guarantee a stable wall-surf. Server corrections/rubber-banding may undo them. Local play may also be corrected by the listen server. The HUD labels `EB LOCAL` / `PX LOCAL` mean this code applied an override, **not** that the server accepted it. This is not an anti-cheat bypass.

## Install

1. Exit the game fully. Do not attempt to hot-unload this module.
2. Replace your existing `libmint_linux.so` with `release/libmint_linux.so`.
3. Keep your existing working launch setup:

```sh
MINT_ENABLE=1 LD_PRELOAD=/absolute/path/libmint_linux.so %command% -insecure
```

Only use offline or on a server you control that permits it. The `-insecure` activation requirement remains. There are **no server files or server modifications** in this package.

The first working version is included as `release/libmint_linux-v1.so` for rollback. Rename/copy it to the active filename only while the game is closed.

## Binds / config

The default config is created at:

```text
~/.config/mint-linux.ini
```

Or set `MINT_CONFIG=/absolute/path/mint-linux.ini` in the launch environment. For a custom path, create its parent directory first. A sample config is included next to this README.

Default controls:

| Action | Key |
|---|---|
| Hold local EB | Left Shift |
| Hold local PX | Left Alt |
| Toggle HUD | F6 |
| Toggle bunnyhop | F7 |
| Toggle movement assists | F8 |
| Reload config | F9 |

Example changes:

```ini
eb_key = Mouse4
px_key = Mouse5
hud_key = F6
bhop_key = F7
assist_key = F8
reload_key = F9
local_physics = 1
px_wall_range = 4
px_fall_speed = 6.25
px_wall_push = 60
eb_ground_range = 12
eb_min_fall_speed = 40
```

Use SDL key names such as `Space`, `Left Ctrl`, `E`, `F10`, or `Mouse1` through `Mouse5`. Numeric SDL scancodes work as `scancode:4`. `None` disables a bind. Invalid names are disabled and logged. This version does not support key chords or an in-game binding editor. Press the **currently assigned** reload key after editing. If you disable it, restart to load further edits.

Existing game bindings are not suppressed. For example, binding EB to Shift can still activate the game's Shift action.

### Mode and tuning

- `local_physics = 1`: v2 synthetic local overrides (default).
- `local_physics = 0`: previous approximate input-only forecasts. These do not gain v2's synthetic behavior.
- `px_wall_range`: distance beyond the player's hull to look for a wall; 0.25–16 units.
- `px_fall_speed`: downward local speed while PX is active; 0–100. `0` attempts a local wall-hang.
- `px_wall_push`: extra local movement input toward the wall; 0–450.
- `eb_ground_range`: downward probe range, 1–64 units. Faster falling also extends the probe up to one tick (capped at 64 units).
- `eb_min_fall_speed`: minimum downward speed for synthetic EB activation, 1–1000.

EB is latched so it does not continuously reset falling at the same edge. Release/repress EB, touch ground, or move 24 units horizontally to rearm it. PX takes priority when both binds are held and wall contact is found. Neither override engages while grounded, swimming, or ascending. Ladders and special movement modes are not fully supported.

Physics defaults: 64 ticks/sec, gravity 800. For other practice settings, set `MINT_TICKRATE=128` and/or `MINT_GRAVITY=800` in the environment. These values affect local EB reset speed and the input-only forecast; they do not change server settings.

## HUD and logs

- `PX LOCAL`: the local PX override ran recently.
- `EB LOCAL`: the local EB override ran recently.
- `PX SIGNAL` / `EB SIGNAL`: older velocity-based heuristic indicators, with possible false positives.
- `HELD`: bind is held, but no matching local geometry/action has been selected.

Expected startup messages include `ProcessMovement hook installed` and `Mint Linux v2 installed`. The first actual local PX/EB override is also logged to stderr. Capture the terminal output when reporting problems.

## Build compatibility

Targets the supplied 64-bit client with ELF build ID:

```text
5f3a5c346699a599c0887bc0c31580e8d49d9003
```

Before patching, checks:

- ClientModeCSNormal vtable `0x21d14b0`, slot 25, original CreateMove `0x8aba30`.
- CCSGameMovement vtable `0x21d2df0`, slot 2, original ProcessMovement `0xf191f0`.

Only `CMoveData` velocity (offset `0x40`) and local forward/side movement inputs (`0x2c` / `0x30`) are overwritten. Origin, ground flags, health, and server state are not changed. Normal native movement still runs. The build refuses an unknown client; if the movement entry is unexpected it falls back to input-only mode.

The binary needs glibc 2.34+ and libstdc++ with GLIBCXX_3.4.21. If Steam's runtime is older, rebuild inside the actual game runtime:

```sh
./build.sh
g++ -std=c++17 -O2 tests.cpp -o /tmp/mint-tests -ldl -pthread
/tmp/mint-tests
```

The source includes `local_features.inc`, so keep it alongside `movement.cpp`. No SDL/OpenGL development libraries are required. Dependencies resolve dynamically in the game.

## Validation / limitations

The user reported the v1 HUD/bunnyhop working. **v2 has not been run in CS:GO here.** Tests use mocked interfaces/geometry; they do not prove real-game compatibility or server acceptance. Tests cover the local velocity override paths, edge latch/rearming, water/ground/rising guards, configuration parsing, bounds, mouse/scancode binds, and the earlier regression tests. ASan/UBSan passes are recorded in `VALIDATION.txt`.

If the game crashes or movement becomes unstable, remove LD_PRELOAD or restore v1 and restart. Never load both versions together. Server correction is an architectural limitation, not something the config can disable.
