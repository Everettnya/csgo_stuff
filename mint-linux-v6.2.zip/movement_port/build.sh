#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p release
g++ -std=c++17 -O2 -Wall -Wextra -Wno-misleading-indentation -fPIC -shared -fvisibility=hidden -Wl,-z,relro,-z,now -Wl,-soname,libmint_linux.so movement.cpp -o release/libmint_linux.so -ldl -pthread
