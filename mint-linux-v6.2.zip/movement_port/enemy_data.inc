struct Matrix {float m[4][4];};
struct EnemyWorld {void*entity=nullptr;bool precise=false,blocked=true,canAim=false;Vec aimPoint;Vec torsoPoint;Vec targetVelocity;float distance2=0;Vec corner[8];int health=0;char name[33]{};};
struct EnemyFrame {Matrix matrix{};EnemyWorld players[64];int count=0,seen=0,dormant=0,models=0,approximate=0,eligible=0,localTeam=0;double updated=0;};
static EnemyFrame enemyFrame;static std::mutex enemyLock;
static int teamOff=-1,lifeOff=-1,viewOff=-1;
static double nowSeconds(){timespec t{};clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec/1e9;}
[[maybe_unused]] static bool project(Vec p,const Matrix&m,int w,int h,float&x,float&y){float d=m.m[3][0]*p.x+m.m[3][1]*p.y+m.m[3][2]*p.z+m.m[3][3];if(!std::isfinite(d)||d<.01f)return false;float nx=(m.m[0][0]*p.x+m.m[0][1]*p.y+m.m[0][2]*p.z+m.m[0][3])/d,ny=(m.m[1][0]*p.x+m.m[1][1]*p.y+m.m[1][2]*p.z+m.m[1][3])/d;x=(nx+1)*w*.5f;y=(1-ny)*h*.5f;return std::isfinite(x)&&std::isfinite(y);}
struct ScreenBox {float left=0,top=0,right=0,bottom=0;};
static bool projectBox(const EnemyWorld&p,const Matrix&m,int w,int h,ScreenBox&b){
 struct Clip {float x,y,w;};Clip c[8];b={1e30f,1e30f,-1e30f,-1e30f};bool any=false;constexpr float near=.01f;
 for(int i=0;i<8;i++){Vec v=p.corner[i];c[i]={m.m[0][0]*v.x+m.m[0][1]*v.y+m.m[0][2]*v.z+m.m[0][3],m.m[1][0]*v.x+m.m[1][1]*v.y+m.m[1][2]*v.z+m.m[1][3],m.m[3][0]*v.x+m.m[3][1]*v.y+m.m[3][2]*v.z+m.m[3][3]};if(!std::isfinite(c[i].x)||!std::isfinite(c[i].y)||!std::isfinite(c[i].w))return false;}
 auto add=[&](Clip v){float x=(v.x/v.w+1)*w*.5f,y=(1-v.y/v.w)*h*.5f;if(!std::isfinite(x)||!std::isfinite(y))return;any=true;b.left=std::min(b.left,x);b.right=std::max(b.right,x);b.top=std::min(b.top,y);b.bottom=std::max(b.bottom,y);};
 for(auto v:c)if(v.w>=near)add(v);
 // Clip all 12 AABB edges against the near plane instead of dropping a whole box.
 for(int i=0;i<8;i++)for(int bit:{1,2,4})if(!(i&bit)){Clip a=c[i],z=c[i|bit];if((a.w>=near)!=(z.w>=near)){float t=(near-a.w)/(z.w-a.w);add({a.x+(z.x-a.x)*t,a.y+(z.y-a.y)*t,near});}}
 if(!any||b.right<0||b.left>w-1||b.bottom<0||b.top>h-1)return false;
 // Keep distant subpixel targets visible without introducing a distance cutoff.
 if(b.right-b.left<3){float mid=(b.left+b.right)*.5f;b.left=mid-1.5f;b.right=mid+1.5f;}
 if(b.bottom-b.top<5){float mid=(b.top+b.bottom)*.5f;b.top=mid-2.5f;b.bottom=mid+2.5f;}
 b.left=std::clamp(b.left,0.f,float(w-1));b.right=std::clamp(b.right,0.f,float(w-1));b.top=std::clamp(b.top,0.f,float(h-1));b.bottom=std::clamp(b.bottom,0.f,float(h-1));return b.right>b.left&&b.bottom>b.top;
}
static void cleanName(char*out,const unsigned char*in,size_t limit){size_t n=0;for(size_t i=0;i<limit&&in[i]&&n<32;i++){unsigned c=in[i];if(c>=32&&c<127)out[n++]=char(c);else if(c>=192)out[n++]='?';}out[n]=0;if(!n)strcpy(out,"PLAYER");}
static Vec eyePosition(void*p){Vec pos=get<Vec>(p,originOff);if(viewOff>=0){Vec view=get<Vec>(p,viewOff);if(std::isfinite(view.z)&&view.z>0&&view.z<100)return pos+view;}return pos+Vec{0,0,std::clamp(get<Vec>(p,maxsOff).z-8,28.f,64.f)};}
static bool pointVisible(void*local,void*target,Vec from,Vec to){if(!trace)return false;Ray r{};Vec d=to-from;r.start={from.x,from.y,from.z,0};r.delta={d.x,d.y,d.z,0};r.isRay=true;r.swept=d.dot(d)>0;Filter filter(local);Trace tr{};tr.fraction=1;reinterpret_cast<void(*)(void*,const Ray&,unsigned,Filter*,Trace*)>((*reinterpret_cast<void***>(trace))[5])(trace,r,0x4600400Bu,&filter,&tr);return !tr.startsolid&&!tr.allsolid&&(tr.fraction>=1.f||tr.entity==target);}
static bool chooseAimPoint(bool headVisible,bool bodyVisible,Vec head,Vec body,Vec&out){if(headVisible){out=head;return true;}if(bodyVisible){out=body;return true;}return false;}
static Vec lookAngles(Vec eye,Vec point){Vec d=point-eye;float len=sqrtf(d.x*d.x+d.y*d.y);return {std::clamp(-atan2f(d.z,len)*float(180/M_PI),-89.f,89.f),atan2f(d.y,d.x)*float(180/M_PI),0};}
static void preserveMovement(Cmd&c,float oldYaw){float a=(c.angles.y-oldYaw)*float(M_PI/180);float f=c.forward,s=c.side;c.forward=std::clamp(cosf(a)*f-sinf(a)*s,-450.f,450.f);c.side=std::clamp(sinf(a)*f+cosf(a)*s,-450.f,450.f);}
static int nearestVisible(const EnemyFrame&frame){int best=-1;float dist=INFINITY;for(int i=0;i<frame.count;i++)if(frame.players[i].canAim&&frame.players[i].distance2<dist){best=i;dist=frame.players[i].distance2;}return best;}
static void aimAtVisible(void*local,Cmd&c){if(!wantAim||get<int>(local,healthOff)<=0)return;EnemyWorld target;{std::lock_guard<std::mutex>g(enemyLock);if(nowSeconds()-enemyFrame.updated>.1)return;int best=nearestVisible(enemyFrame);if(best<0){static double last=0;if(nowSeconds()-last>5){last=nowSeconds();char status[240];snprintf(status,sizeof status,"Aim held: no visible eligible target. seen=%d enemy=%d dormant=%d precise=%d approx=%d; %s",enemyFrame.seen,enemyFrame.eligible,enemyFrame.dormant,enemyFrame.models,enemyFrame.approximate,modelReason());log(status);}return;}target=enemyFrame.players[best];}static int previousMode=-1;int mode=target.precise?1:0;if(mode!=previousMode){previousMode=mode;std::string message=mode?"Aim active: animated hitbox centers.":std::string("Aim active: approximate fallback; ")+modelReason();log(message.c_str());}Vec eye=eyePosition(local)+get<Vec>(local,velOff)*(dt*config.aimEyeLead);Vec destination=target.aimPoint+target.targetVelocity*(dt*config.aimLead);if(!pointVisible(local,target.entity,eye,destination))destination=target.aimPoint;if(!pointVisible(local,target.entity,eye,destination)){destination=target.torsoPoint+target.targetVelocity*(dt*config.aimLead);if(!pointVisible(local,target.entity,eye,destination))return;}float yaw=c.angles.y;c.angles=lookAngles(eye,destination);preserveMovement(c,yaw);reinterpret_cast<void(*)(void*,const Vec&)>((*reinterpret_cast<void***>(engine))[19])(engine,c.angles);}
static void collectEnemies(void*local){EnemyFrame frame;frame.updated=nowSeconds();if((enemyOverlay||wantAim)&&teamOff>=0&&lifeOff>=0&&local&&call<bool>(engine,26)){
 int localTeam=get<int>(local,teamOff);frame.localTeam=localTeam;if(localTeam==2||localTeam==3){frame.matrix=call<const Matrix&>(engine,37);for(int i=1;i<=64;i++){
  void*p=call<void*>(entities,3,i);if(!p||p==local)continue;frame.seen++;int team=get<int>(p,teamOff),hp=get<int>(p,healthOff);if((team!=2&&team!=3)||team==localTeam||hp<=0||get<unsigned char>(p,lifeOff)!=0)continue;frame.eligible++;
  // Verified in uploaded C_CSPlayer: GetClientNetworkable slot 5 returns this+0x10;
  // networkable slot 9 is the IsDormant adjustment thunk (0x7bbf30 -> 0x7bbf00).
  // Slot 8 is NOT IsDormant on this build; v3 called the wrong function.
  void*network=call<void*>(p,5);if(!network)continue;if(call<bool>(network,9)){frame.dormant++;continue;}
  Vec origin=get<Vec>(p,originOff),mi=get<Vec>(p,minsOff),ma=get<Vec>(p,maxsOff);if(!std::isfinite(origin.x)||!std::isfinite(origin.y)||!std::isfinite(origin.z)||ma.z-mi.z<10||ma.z-mi.z>120)continue;
  EnemyWorld e;e.entity=p;e.targetVelocity=get<Vec>(p,velOff);Vec eye=eyePosition(local),head=origin+Vec{(mi.x+ma.x)*.5f,(mi.y+ma.y)*.5f,ma.z-5},body=origin+Vec{(mi.x+ma.x)*.5f,(mi.y+ma.y)*.5f,mi.z+(ma.z-mi.z)*.55f};bool precise=animatedTargets(p,head,body);if(precise)frame.models++;bool hv=pointVisible(local,p,eye,head),bv=pointVisible(local,p,eye,body);e.torsoPoint=body;e.blocked=!hv&&!bv;e.precise=precise;e.canAim=(precise||config.aimFallback)&&chooseAimPoint(hv,bv,head,body,e.aimPoint);if(!precise&&e.canAim)frame.approximate++;Vec delta=origin-get<Vec>(local,originOff);e.distance2=delta.dot(delta);e.health=std::clamp(hp,0,100);for(int c=0;c<8;c++)e.corner[c]=origin+Vec{c&1?ma.x:mi.x,c&2?ma.y:mi.y,c&4?ma.z:mi.z};
  alignas(16) unsigned char info[512]{};if(call<bool>(engine,8,i,(void*)info))cleanName(e.name,info+16,128);else snprintf(e.name,sizeof e.name,"PLAYER %d",i);
  frame.players[frame.count++]=e;
 }}
 }std::lock_guard<std::mutex>g(enemyLock);enemyFrame=frame;}
