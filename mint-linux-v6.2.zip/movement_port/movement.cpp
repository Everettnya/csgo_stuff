#include <dlfcn.h>
#include <link.h>
#include <pthread.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <cstdint>
#include <cstddef>
#include <algorithm>
#include <mutex>
#include <atomic>
#include <string>
#include <fstream>
#include <time.h>
#include <cwchar>

// Build-specific recreation, not recovered Mint source. See README.md.
namespace mint {
struct Vec {float x=0,y=0,z=0; Vec operator+(Vec b)const{return{x+b.x,y+b.y,z+b.z};} Vec operator-(Vec b)const{return{x-b.x,y-b.y,z-b.z};} Vec operator*(float s)const{return{x*s,y*s,z*s};} float dot(Vec b)const{return x*b.x+y*b.y+z*b.z;} };
struct Cmd {void* vptr; int number,tick; Vec angles,aim; float forward,side,up; int buttons; unsigned char impulse; unsigned char pad[3];int weapon,subtype,seed;short dx,dy;bool predicted;};
static_assert(offsetof(Cmd,buttons)==52);
struct Prop {const char* name;int type,flags,buf;bool inside;char pad[3];void* extra;Prop* array;void* lengthProxy;void* proxy;void* tableProxy;struct Table* table;int offset,stride,count;const char* parent;};
struct Table {Prop* props;int count;void* decoder;const char* name;bool init,inMain;};
struct Class {void* create;void* event;const char* name;Table* table;Class* next;int id;};
static_assert(sizeof(Prop)==96);
template<class R,class... A> R call(void* o,int n,A... a){return reinterpret_cast<R(*)(void*,A...)>((*reinterpret_cast<void***>(o))[n])(o,a...);}
static void *engine,*entities,*trace,*client;static uintptr_t base;static std::atomic<bool> initialized{false};
static void log(const char*s){fprintf(stderr,"[mint-linux] %s\n",s);}
static int findprop(Table*t,const char*name,int depth=0){if(!t||depth>24||t->count<0||t->count>4096)return -1;for(int i=0;i<t->count;i++){auto&p=t->props[i];if(p.name&&!strcmp(p.name,name))return p.offset;if(p.table){int r=findprop(p.table,name,depth+1);if(r>=0)return p.offset+r;}}return -1;}
static int net(const char* table,const char* prop){for(Class*c=call<Class*>(client,8);c;c=c->next)if(c->table&&c->table->name&&!strcmp(c->table->name,table))return findprop(c->table,prop);return -1;}
static int flagsOff,velOff,originOff,healthOff,minsOff,maxsOff,waterOff;
template<class T>T get(void*p,int o){T t{};if(o>=0)memcpy(&t,(char*)p+o,sizeof t);return t;}
struct alignas(16) AV {float x,y,z,w;};
struct Ray {AV start,delta,offset,extents;const void* transform;bool isRay,swept;};
struct Plane {Vec normal;float distance;unsigned char type,sign,pad[2];};
struct Surface {const char* name;short props;unsigned short flags;};
struct Trace {Vec start,end;Plane plane;float fraction;int contents;unsigned short disp;bool allsolid,startsolid;float left;Surface surface;int hitgroup;short bone;unsigned short world;void* entity;int hitbox;};
static_assert(offsetof(Trace,fraction)==44&&offsetof(Trace,entity)==88&&sizeof(Trace)==104);
struct Filter {void* skip;explicit Filter(void*p):skip(p){} virtual bool should(void*p,int){return p!=skip;} virtual int type(){return 0;}};
static Trace hull(void*p,Vec a,Vec b,Vec mi,Vec ma){Ray r{};Vec d=b-a,e=(ma-mi)*.5f,c=(ma+mi)*.5f,s=a+c;r.start={s.x,s.y,s.z,0};r.delta={d.x,d.y,d.z,0};r.extents={e.x,e.y,e.z,0};r.offset={-c.x,-c.y,-c.z,0};r.isRay=e.dot(e)<1e-6f;r.swept=d.dot(d)>0;Filter f(p);Trace t{};t.fraction=1;reinterpret_cast<void(*)(void*,const Ray&,unsigned,Filter*,Trace*)>((*reinterpret_cast<void***>(trace))[5])(trace,r,0x201400Bu,&f,&t);return t;}
struct Snapshot {float speed=0,vz=0;bool ebLocal=false,pxLocal=false;bool ground=false,eb=false,px=false,ebHold=false,pxHold=false,ebPlan=false,pxPlan=false;float graph[160]{};unsigned frame=0;};
static Snapshot snap;static std::mutex lock;static std::atomic<bool> hud{true},bhop{true},assists{true};
static std::atomic<bool> enemyOverlay{true},enemyDiagnostics{true},enemySnaplines{true},enemyStick{true};
static float dt=1.f/64.f,gravity=800;static unsigned ebUntil=0,pxUntil=0;static Vec prevVel;static bool prevGround=true;static unsigned ticks=0;
static void* sdlSymbol(const char*n){void*p=dlsym(RTLD_NEXT,n);if(!p){void*h=dlopen("libSDL2-2.0.so.0",RTLD_NOW|RTLD_NOLOAD);if(h){p=dlsym(h,n);dlclose(h);}}return p;}
static const unsigned char*keys(){auto f=(const unsigned char*(*)(int*))sdlSymbol("SDL_GetKeyboardState");return f?f(nullptr):nullptr;}
#include "local_features.inc"
#include "model_targets.inc"
#include "enemy_data.inc"
struct Outcome {bool eb=false,px=false;int when=99;};
// Approximate local hull forecast, NOT the engine's prediction/rollback system.
static Outcome forecast(void*player,Vec pos,Vec velocity,Vec mi,Vec ma,const Cmd&c,bool duck,float scale,bool pixels){
 Outcome out;ma.z=duck?54.f:72.f;float yaw=c.angles.y*float(M_PI/180.0);Vec wish{cosf(yaw)*c.forward+sinf(yaw)*c.side,sinf(yaw)*c.forward-cosf(yaw)*c.side,0};float length=sqrtf(wish.dot(wish));if(length>0)wish=wish*(std::min(length,30.f)/length);
 for(int tick=0;tick<6;tick++){
  // Default Source air acceleration approximation; server settings may differ.
  Vec w=wish*scale;float wl=sqrtf(w.dot(w));if(wl>0){Vec dir=w*(1/wl);float add=wl-velocity.dot(dir);if(add>0)velocity=velocity+dir*std::min(add,12.f*450.f*dt);}
  velocity.z-=gravity*dt*.5f;float remain=dt;bool groundHit=false,wall=false;
  for(int bump=0;bump<4&&remain>0.00001f;bump++) {auto tr=hull(player,pos,pos+velocity*remain,mi,ma);if(tr.startsolid||tr.allsolid)return out;pos=tr.end;if(tr.fraction>=1)break;groundHit|=tr.plane.normal.z>.7f;wall|=fabsf(tr.plane.normal.z)<.1f;remain*=1-tr.fraction;float into=velocity.dot(tr.plane.normal);if(into<0)velocity=velocity-tr.plane.normal*into;}
  velocity.z-=gravity*dt*.5f;auto down=hull(player,pos,pos+Vec{0,0,-2},mi,ma);bool supported=down.fraction<1&&down.plane.normal.z>.7f;
  if(groundHit&&!supported){out.eb=true;out.px=pixels&&wall&&fabsf(velocity.z+gravity*dt*.5f)<1.f;out.when=tick;return out;}
  if(supported)return out;
 }
 return out;
}
using Move=bool(*)(void*,float,Cmd*);static Move original;
static bool createMove(void*self,float sample,Cmd*c){bool result=original(self,sample,c);if(!c||!c->number||!initialized)return result;
 if(!call<bool>(engine,26))return result;int index=call<int>(engine,12);if(index<1||index>64)return result;void*p=call<void*>(entities,3,index);if(!p)return result;
 const unsigned char*k=keys();updateBinds(k);collectEnemies(p);aimAtVisible(p,*c);if(get<int>(p,healthOff)<=0)return result;
 bool ebHold=wantEB,pxHold=wantPX;int flags=get<int>(p,flagsOff);bool ground=flags&1;Vec v=get<Vec>(p,velOff),pos=get<Vec>(p,originOff);++ticks;
 // Observed-state heuristics, not proof of a successful exploit.
 bool localRecent=(localEBStamp&&ticks-localEBStamp<64)||(localPXStamp&&ticks-localPXStamp<64);
 bool eb=!localRecent&&!ground&&!prevGround&&prevVel.z < -20&&fabsf(v.z+gravity*dt*.5f)<.75f;
 bool px=!localRecent&&!ground&&!prevGround&&fabsf(v.z+gravity*dt*.5f)<.75f&&fabsf(v.z-prevVel.z)<.75f;
 if(eb)ebUntil=ticks+32;if(px)pxUntil=ticks+16;
 bool ebPlan=false,pxPlan=false;
 if(!config.local&&!ground&&get<unsigned char>(p,waterOff)<2&&(ebHold||pxHold)&&trace){Vec mi=get<Vec>(p,minsOff),ma=get<Vec>(p,maxsOff);if(ma.z>20&&ma.z<100&&ma.x>0&&ma.x<40){int best=99;Cmd chosen=*c;for(int duck=0;duck<2;duck++)for(float scale:{1.f,0.f}){auto o=forecast(p,pos,v,mi,ma,*c,duck,scale,pxHold);bool eligible=(ebHold&&o.eb)||(pxHold&&o.px);if(eligible&&o.when<best){best=o.when;chosen=*c;chosen.buttons=(chosen.buttons&~4)|(duck?4:0);chosen.forward*=scale;chosen.side*=scale;ebPlan=o.eb;pxPlan=o.px;}}if(best<99){c->buttons=chosen.buttons;c->forward=chosen.forward;c->side=chosen.side;}}}
 if(bhop&&(c->buttons&2)&&!ground&&!(flags&(1<<9))&&get<unsigned char>(p,waterOff)<2)c->buttons&=~2;
 {std::lock_guard<std::mutex>g(lock);snap.ebLocal=localEBStamp&&ticks-localEBStamp<32;snap.pxLocal=localPXStamp&&ticks-localPXStamp<32;snap.speed=sqrtf(v.x*v.x+v.y*v.y);snap.vz=v.z;snap.ground=ground;snap.eb=ticks<=ebUntil;snap.px=ticks<=pxUntil;snap.ebHold=ebHold;snap.pxHold=pxHold;snap.ebPlan=ebPlan;snap.pxPlan=pxPlan;snap.graph[snap.frame++%160]=snap.speed;}
 prevVel=v;prevGround=ground;return result;
}
struct Module {const char* suffix;uintptr_t base=0;std::string path;};
static int locate(dl_phdr_info*i,size_t,void*d){auto&m=*static_cast<Module*>(d);const char*p=strrchr(i->dlpi_name,'/');p=p?p+1:i->dlpi_name;if(!strcmp(p,m.suffix)){m.base=i->dlpi_addr;m.path=i->dlpi_name;return 1;}return 0;}
static void* iface(const char*path,const char*name){void*h=dlopen(path,RTLD_NOW|RTLD_NOLOAD);if(!h)return nullptr;auto f=(void*(*)(const char*,int*))dlsym(h,"CreateInterface");return f?f(name,nullptr):nullptr;}
static bool expected(const char*path){std::ifstream f(path,std::ios::binary);if(!f)return false;std::string b((std::istreambuf_iterator<char>(f)),{});const unsigned char id[]={0x5f,0x3a,0x5c,0x34,0x66,0x99,0xa5,0x99,0xc0,0x88,0x7b,0xc0,0xc3,0x15,0x80,0xe8,0xd4,0x9d,0x90,0x03};return b.find(std::string((const char*)id,20))!=std::string::npos;}
#include "native_hud.inc"
static void* init(void*){for(int n=0;n<240;n++){Module cm{"client_client.so",0,{}},em{"engine_client.so",0,{}};dl_iterate_phdr(locate,&cm);dl_iterate_phdr(locate,&em);if(!cm.base||!em.base){usleep(250000);continue;}if(!expected(cm.path.c_str())){log("Client build ID does not match supplied binary; refusing to patch.");return nullptr;}
 client=iface(cm.path.c_str(),"VClient018");engine=iface(em.path.c_str(),"VEngineClient014");entities=iface(cm.path.c_str(),"VClientEntityList003");trace=iface(em.path.c_str(),"EngineTraceClient004");if(!client||!engine||!entities||!trace){log("Missing required interface; no hooks installed.");return nullptr;}
 flagsOff=net("DT_BasePlayer","m_fFlags");velOff=net("DT_BasePlayer","m_vecVelocity[0]");originOff=net("DT_BaseEntity","m_vecOrigin");healthOff=net("DT_BasePlayer","m_iHealth");minsOff=net("DT_BaseEntity","m_vecMins");maxsOff=net("DT_BaseEntity","m_vecMaxs");waterOff=net("DT_BasePlayer","m_nWaterLevel");if(std::min({flagsOff,velOff,originOff,healthOff,minsOff,maxsOff,waterOff})<0){log("Missing required receive property; no hooks installed.");return nullptr;}
 if(const char*v=getenv("MINT_TICKRATE")){float t=atof(v);if(t>=32&&t<=256)dt=1/t;}if(const char*v=getenv("MINT_GRAVITY")){float t=atof(v);if(t>0&&t<4000)gravity=t;}
 modelInfo=iface(em.path.c_str(),"VModelInfoClient004");hitboxSetOff=net("DT_BaseAnimating","m_nHitboxSet");if(!modelInfo)log("Model info unavailable; precise aim will remain inactive.");
 viewOff=net("DT_BasePlayer","m_vecViewOffset[0]");teamOff=net("DT_BaseEntity","m_iTeamNum");lifeOff=net("DT_BasePlayer","m_lifeState");if(teamOff<0||lifeOff<0)log("Enemy overlay disabled: missing team/life properties.");
 loadConfig();
 // RTTI-backed ClientModeCSNormal vtable and CreateMove body verified offline.
 base=cm.base;auto slot=(void**)(base+0x21d14b0+25*8);if(*slot!=(void*)(base+0x8aba30)){log("Unexpected CreateMove slot; refusing to patch.");return nullptr;}
 long page=sysconf(_SC_PAGESIZE);
 auto patch=[&](void**s,void*f){uintptr_t address=(uintptr_t)s&~(uintptr_t(page)-1);if(mprotect((void*)address,page,PROT_READ|PROT_WRITE))return false;__atomic_store_n(s,f,__ATOMIC_RELEASE);mprotect((void*)address,page,PROT_READ);return true;};
 auto movementSlot=(void**)(base+0x21d2df0+2*8);
 if(*movementSlot!=(void*)(base+0xf191f0)){log("Unexpected ProcessMovement slot; refusing local-physics hook.");config.local=false;localMode=false;}
 else {originalProcess=(Process)*movementSlot;if(!patch(movementSlot,(void*)&processMovement)){log("ProcessMovement hook failed; input-only mode.");config.local=false;localMode=false;}else log("ProcessMovement hook installed. Local velocity overrides are NOT server-authoritative.");}
 original=(Move)*slot;initialized=true;if(!patch(slot,(void*)&createMove)){initialized=false;log("CreateMove patch failed.");return nullptr;}
 installNative();
 log("Mint Linux v6 installed. Bindings configurable; default F9 reloads config.");return nullptr;}log("Timed out waiting for game libraries.");return nullptr;}
}
namespace mint {
// Compatibility-profile OpenGL overlay. No SDL/OpenGL headers or linked GL dependency.
struct GL {
 void(*push)(unsigned);void(*pop)();void(*matrix)(unsigned);void(*pushMatrix)();void(*popMatrix)();void(*identity)();void(*ortho)(double,double,double,double,double,double);void(*disable)(unsigned);void(*enable)(unsigned);void(*blend)(unsigned,unsigned);void(*begin)(unsigned);void(*end)();void(*vertex)(float,float);void(*color)(float,float,float,float);void(*get)(unsigned,int*);void(*viewport)(int,int,int,int);void(*polygon)(unsigned,unsigned);void(*program)(unsigned);void(*colorMask)(unsigned char,unsigned char,unsigned char,unsigned char);
 bool setup(){
  void*h=dlopen("libGL.so.1",RTLD_LAZY|RTLD_NOLOAD);if(!h)return false;
#define GLGET(field,name) field=reinterpret_cast<decltype(field)>(dlsym(h,name));if(!field){dlclose(h);return false;}
 GLGET(program,"glUseProgram") GLGET(colorMask,"glColorMask") GLGET(push,"glPushAttrib") GLGET(pop,"glPopAttrib") GLGET(matrix,"glMatrixMode") GLGET(pushMatrix,"glPushMatrix") GLGET(popMatrix,"glPopMatrix") GLGET(identity,"glLoadIdentity") GLGET(ortho,"glOrtho") GLGET(disable,"glDisable") GLGET(enable,"glEnable") GLGET(blend,"glBlendFunc") GLGET(begin,"glBegin") GLGET(end,"glEnd") GLGET(vertex,"glVertex2f") GLGET(color,"glColor4f") GLGET(get,"glGetIntegerv") GLGET(viewport,"glViewport") GLGET(polygon,"glPolygonMode")
#undef GLGET
 dlclose(h);return true;}
};static GL gl;
static void quad(float x,float y,float w,float h){gl.vertex(x,y);gl.vertex(x+w,y);gl.vertex(x+w,y+h);gl.vertex(x,y+h);}
static const char* glyph(char c){if(c=='e')return "00000000000111010001111111000001110";if(c=='b')return "10000100001011011001100011000111110";if(c=='p')return "00000000001111010001111101000010000";if(c=='x')return "00000000001000101010001000101010001";if(c=='u')return "00000000001000110001100011001101101";if(c=='s')return "00000000000111110000011100000111110";if(c>='a'&&c<='z')c-=32;switch(c){
 case '0':return "01110100011001110101110011000101110";case '1':return "00100011000010000100001000010001110";case '2':return "01110100010000100010001000100011111";case '3':return "11110000010000101110000010000111110";case '4':return "00010001100101010010111110001000010";case '5':return "11111100001000011110000010000111110";case '6':return "01110100001000011110100011000101110";case '7':return "11111000010001000100010000100001000";case '8':return "01110100011000101110100011000101110";case '9':return "01110100011000101111000010000101110";
 case 'A':return "01110100011000111111100011000110001";case 'B':return "11110100011000111110100011000111110";case 'C':return "01110100011000010000100001000101110";case 'D':return "11110100011000110001100011000111110";case 'E':return "11111100001000011110100001000011111";case 'F':return "11111100001000011110100001000010000";case 'G':return "01110100011000010111100011000101110";case 'H':return "10001100011000111111100011000110001";case 'I':return "01110001000010000100001000010001110";case 'J':return "00111000100001000010100101001001100";case 'Q':return "01110100011000110001101011001001101";case 'Z':return "11111000010001000100010001000011111";case '?':return "01110100010000100010001000000000100";case '_':return "00000000000000000000000000000011111";case '.':return "00000000000000000000000000011000110";case 'K':return "10001100101010011000101001001010001";case 'L':return "10000100001000010000100001000011111";case 'M':return "10001110111010110101100011000110001";case 'N':return "10001110011010110011100011000110001";case 'O':return "01110100011000110001100011000101110";case 'P':return "11110100011000111110100001000010000";case 'R':return "11110100011000111110101001001010001";case 'S':return "01111100001000001110000010000111110";case 'T':return "11111001000010000100001000010000100";case 'U':return "10001100011000110001100011000101110";case 'V':return "10001100011000110001100010101000100";case 'Y':return "10001100010101000100001000010000100";case 'W':return "10001100011000110101101011010101010";case 'X':return "10001100010101000100010101000110001";case '+':return "00000001000010011111001000010000000";case ':':return "00000001000010000000001000010000000";case '-':return "00000000000000011111000000000000000";case '/':return "00001000100001000100010000100010000";case ' ':return "00000000000000000000000000000000000";default:return "01110100010000100010001000000000100";}}
static void text(float x,float y,const char*s,int scale){for(;*s;s++,x+=6*scale){const char*g=glyph(*s);for(int r=0;r<7;r++)for(int c=0;c<5;c++)if(g[r*5+c]=='1')quad(x+c*scale,y+r*scale,scale,scale);}}
static void outline(float x,float y,float w,float h,float thick){quad(x,y,w,thick);quad(x,y+h-thick,w,thick);quad(x,y,thick,h);quad(x+w-thick,y,thick,h);}
static void line(float x1,float y1,float x2,float y2,float width){float dx=x2-x1,dy=y2-y1,len=sqrtf(dx*dx+dy*dy);if(len<.001f)return;float px=-dy/len*width*.5f,py=dx/len*width*.5f;gl.vertex(x1+px,y1+py);gl.vertex(x2+px,y2+py);gl.vertex(x2-px,y2-py);gl.vertex(x1-px,y1-py);}
static void stick(const ScreenBox&b){
 // Thin reference-style, box-relative illustration; not animated model bones.
 static constexpr float segments[][4]={
  {.46f,.05f,.57f,.06f},{.57f,.06f,.56f,.14f},{.56f,.14f,.45f,.14f},{.45f,.14f,.46f,.05f},
  {.50f,.14f,.49f,.20f},
  {.49f,.20f,.36f,.23f},{.49f,.20f,.64f,.23f},
  {.49f,.20f,.50f,.39f},{.50f,.39f,.48f,.55f},
  {.36f,.23f,.26f,.35f},{.26f,.35f,.43f,.39f},
  {.64f,.23f,.73f,.34f},{.73f,.34f,.83f,.32f},
  {.48f,.55f,.41f,.60f},{.48f,.55f,.57f,.60f},
  {.41f,.60f,.32f,.78f},{.32f,.78f,.23f,.95f},
  {.57f,.60f,.65f,.78f},{.65f,.78f,.76f,.95f},
  {.23f,.95f,.16f,.97f},{.76f,.95f,.83f,.97f}
 };
 float w=b.right-b.left,h=b.bottom-b.top;
 for(auto&s:segments)line(b.left+s[0]*w,b.top+s[1]*h,b.left+s[2]*w,b.top+s[3]*h,1.f);
}
static int drawEnemies(const EnemyFrame&f,int w,int h){int drawn=0;for(int i=0;i<f.count;i++){const auto&p=f.players[i];ScreenBox b;if(!projectBox(p,f.matrix,w,h,b))continue;drawn++;float bw=b.right-b.left,bh=b.bottom-b.top;
 if(enemySnaplines){float endx=(b.left+b.right)*.5f;gl.color(0,0,0,.8f);line(w*.5f,h-1,endx,b.bottom,3);gl.color(.4f,.85f,1,.8f);line(w*.5f,h-1,endx,b.bottom,1);}
 if(enemyStick&&p.blocked){gl.color(1,1,1,1);stick(b);}
 gl.color(0,0,0,.95f);outline(b.left-1,b.top-1,bw+2,bh+2,3);gl.color(1,.3f,.25f,1);outline(b.left,b.top,bw,bh,1);
 float ratio=std::clamp(p.health/100.f,0.f,1.f);float barx=std::min(b.right+4,float(w-7));gl.color(0,0,0,.95f);quad(barx,b.top-1,6,bh+2);gl.color(.12f,.12f,.12f,1);quad(barx+1,b.top,4,bh);gl.color(1-ratio,ratio,.15f,1);quad(barx+1,b.bottom-bh*ratio,4,bh*ratio);
 int scale=bh>160?2:1;float tx=(b.left+b.right)*.5f-strlen(p.name)*6*scale*.5f,ty=std::max(2.f,b.top-7*scale-5);tx=std::clamp(tx,0.f,std::max(0.f,w-float(strlen(p.name)*6*scale)));gl.color(0,0,0,1);text(tx+1,ty+1,p.name,scale);gl.color(1,1,1,1);text(tx,ty,p.name,scale);
 }return drawn;}
static void render(void*window){if(!initialized||(!hud&&!enemyOverlay&&!enemyDiagnostics))return;static bool ready=false;if(!ready)ready=gl.setup();if(!ready)return;auto size=(void(*)(void*,int*,int*))sdlSymbol("SDL_GL_GetDrawableSize");if(!size)return;int w=0,h=0;size(window,&w,&h);if(w<320||h<240)return;Snapshot s;{std::lock_guard<std::mutex>g(lock);s=snap;}EnemyFrame enemies;{std::lock_guard<std::mutex>g(enemyLock);enemies=enemyFrame;}if(nowSeconds()-enemies.updated>.3)enemies.count=0;if(!s.frame&&!enemies.count&&!enemyDiagnostics)return;
 int mode,program;gl.get(0x0BA0,&mode);gl.get(0x8B8D,&program);gl.push(0x000fffff);gl.program(0);gl.colorMask(1,1,1,1);gl.viewport(0,0,w,h);gl.disable(0x0B71);gl.disable(0x0B44);gl.disable(0x0DE1);gl.disable(0x0B50);gl.disable(0x0B60);gl.disable(0x0C11);gl.disable(0x0B90);gl.disable(0x0BC0);gl.enable(0x0BE2);gl.blend(0x0302,0x0303);gl.polygon(0x0408,0x1B02);gl.matrix(0x1701);gl.pushMatrix();gl.identity();gl.ortho(0,w,h,0,-1,1);gl.matrix(0x1700);gl.pushMatrix();gl.identity();
 gl.begin(7);int drawn=enemyOverlay?drawEnemies(enemies,w,h):0;if(enemyDiagnostics){char status[160];snprintf(status,sizeof status,"ESP %s TEAM %d SEEN %d ENEMY %d DORM %d BONES %d APPROX %d DRAW %d",enemyOverlay?"ON":"OFF",enemies.localTeam,enemies.seen,enemies.eligible,enemies.dormant,enemies.models,enemies.approximate,drawn);gl.color(0,0,0,.8f);quad(12,12,strlen(status)*6+12,23);gl.color(1,1,1,1);text(18,20,status,1);}if(hud&&s.frame&&!nativeActive()){float y=h*.75f;char speed[32];snprintf(speed,sizeof speed,"%.0f",s.speed);float center=w*.5f;gl.color(1,1,1,1);text(center-strlen(speed)*6,y,speed,2);text(center-9,y+18,"u/s",1);
 float peak=320;for(float v:s.graph)peak=std::max(peak,v);float gx=center-70,base=y+58;gl.color(1,1,1,.3f);quad(gx,base,140,1);gl.color(1,1,1,1);unsigned count=std::min(s.frame,160u);for(unsigned i=1;i<count;i++){unsigned first=s.frame>=160?s.frame%160:0;float a=s.graph[(first+i-1)%160]/peak,b=s.graph[(first+i)%160]/peak;line(gx+(i-1)*140.f/159,base-a*22,gx+i*140.f/159,base-b*22,1);}
 auto eb=indicator(s.ebHold,s.eb,s.ebLocal),px=indicator(s.pxHold,s.px,s.pxLocal);if(eb.show){gl.color(eb.r/255.f,eb.g/255.f,eb.b/255.f,1);text(center-24,base+8,"eb",1);}if(px.show){gl.color(px.r/255.f,px.g/255.f,px.b/255.f,1);text(center+12,base+8,"px",1);}
 }gl.end();gl.popMatrix();gl.matrix(0x1701);gl.popMatrix();gl.matrix(mode);gl.pop();gl.program(program);}
}
extern "C" __attribute__((visibility("default"))) void SDL_GL_SwapWindow(void*window){using F=void(*)(void*);static F real=(F)mint::sdlSymbol("SDL_GL_SwapWindow");if(!real)return;mint::render(window);real(window);}
static bool activationEnabled(const char*value){return value&&!strcmp(value,"1");}
__attribute__((constructor)) static void load(){if(!activationEnabled(getenv("MINT_ENABLE")))return;mint::log("Enabled via MINT_ENABLE=1; no -insecure requirement. This does not bypass anti-cheat.");pthread_t t;if(!pthread_create(&t,nullptr,mint::init,nullptr))pthread_detach(t);}
