// v2: configurable bindings and explicitly local synthetic physics.
struct Config {
 std::string eb="Left Shift",px="Left Alt",hud="F6",bhop="F7",assist="F8",reload="F9",esp="F10",aim="Mouse4";
 bool aimFallback=true,aimEnabled=true,lines=true,stick=true,debug=false,local=true;float aimLead=0,aimEyeLead=0,wallRange=4,pxFall=6.25f,wallPush=60,edgeRange=12,edgeMinFall=40;
};
static Config& configValue(){static Config value;return value;}
#define config configValue()
static std::string& configPathValue(){static std::string value;return value;}
#define configPath configPathValue()
struct Bind {int code=-1;bool mouse=false;};
static Bind ebBind,pxBind,hudBind,bhopBind,assistBind,reloadBind,espBind,aimBind;
static std::atomic<bool> wantEB{false},wantPX{false},wantAim{false};
static std::atomic<unsigned> localEBStamp{0},localPXStamp{0};
static std::atomic<bool> localMode{true};
static std::string trim(std::string s){auto a=s.find_first_not_of(" \t\r\n");return a==std::string::npos?"":s.substr(a,s.find_last_not_of(" \t\r\n")-a+1);}
static Bind parseBind(std::string s){
 if(s=="None"||s=="none"||s=="disabled")return {};
 if(s.size()==6&&(s.substr(0,5)=="Mouse"||s.substr(0,5)=="mouse")&&s[5]>='1'&&s[5]<='5')return {s[5]-'0',true};
 if(s.rfind("scancode:",0)==0){int v=0;if(s.size()==9)return {};for(size_t i=9;i<s.size();i++){if(s[i]<'0'||s[i]>'9')return {};v=v*10+(s[i]-'0');if(v>=512)return {};}return v>0?Bind{v,false}:Bind{};}
 auto f=(int(*)(const char*))sdlSymbol("SDL_GetScancodeFromName");int code=f?f(s.c_str()):0;
 // Defaults can resolve before SDL is globally visible.
 if(!code){if(s=="Left Shift")code=225;else if(s=="Left Alt")code=226;else if(s=="F6")code=63;else if(s=="F7")code=64;else if(s=="F8")code=65;else if(s=="F9")code=66;else if(s=="F10")code=67;}
 if(code<=0||code>=512){std::string message="Unknown bind (disabled): "+s;log(message.c_str());return {};}
 return {code,false};
}
static bool held(Bind b,const unsigned char*k){if(b.code<0)return false;if(!b.mouse)return k&&k[b.code];auto f=(unsigned(*)(int*,int*))sdlSymbol("SDL_GetMouseState");return f&&(f(nullptr,nullptr)&(1u<<(b.code-1)));}
static const char* defaultConfig=R"CFG(# Mint Linux v6.2 — local physics, NOT server-authoritative.
# SDL key names, Mouse1..Mouse5, scancode:NN, or None.
eb_key = Left Shift
px_key = Left Alt
hud_key = F6
bhop_key = F7
assist_key = F8
reload_key = F9
esp_key = F10
aim_key = Mouse4
aim_enabled = 1
aim_allow_approximate = 1
aim_lead_ticks = 0
aim_eye_lead_ticks = 0
esp_debug = 0
esp_snaplines = 1
esp_stick_figure = 1
# 1 = synthetic local wall-surf/edge-save; 0 = old input-only forecast.
local_physics = 1
px_wall_range = 4
px_fall_speed = 6.25
px_wall_push = 60
eb_ground_range = 12
eb_min_fall_speed = 40
)CFG";
static float number(const std::string&s,float fallback,float lo,float hi){char*e=nullptr;float v=strtof(s.c_str(),&e);return e&&!*e&&std::isfinite(v)&&v>=lo&&v<=hi?v:fallback;}
static void loadConfig(){
 if(configPath.empty()){if(const char*p=getenv("MINT_CONFIG"))configPath=p;else if(const char*h=getenv("HOME")){std::string dir=std::string(h)+"/.config";mkdir(dir.c_str(),0700);configPath=dir+"/mint-linux.ini";}else configPath="mint-linux.ini";}
 std::ifstream in(configPath);if(!in){std::ofstream out(configPath);if(out)out<<defaultConfig;else log("Could not create config; using defaults.");in.open(configPath);}
 Config next;std::string line;
 while(std::getline(in,line)){line=line.substr(0,line.find('#'));auto eq=line.find('=');if(eq==std::string::npos)continue;auto k=trim(line.substr(0,eq)),v=trim(line.substr(eq+1));
  if(k=="eb_key")next.eb=v;else if(k=="px_key")next.px=v;else if(k=="hud_key")next.hud=v;else if(k=="bhop_key")next.bhop=v;else if(k=="assist_key")next.assist=v;else if(k=="reload_key")next.reload=v;else if(k=="esp_key")next.esp=v;else if(k=="aim_key")next.aim=v;
  else if(k=="aim_allow_approximate")next.aimFallback=number(v,1,0,1)!=0;
  else if(k=="aim_enabled")next.aimEnabled=number(v,1,0,1)!=0;
  else if(k=="aim_lead_ticks")next.aimLead=number(v,0,0,2);
  else if(k=="aim_eye_lead_ticks")next.aimEyeLead=number(v,0,0,2);
  else if(k=="esp_snaplines")next.lines=number(v,1,0,1)!=0;
  else if(k=="esp_stick_figure")next.stick=number(v,1,0,1)!=0;
  else if(k=="esp_debug")next.debug=number(v,1,0,1)!=0;
  else if(k=="local_physics")next.local=number(v,1,0,1)!=0;
  else if(k=="px_wall_range")next.wallRange=number(v,4,.25,16);
  else if(k=="px_fall_speed")next.pxFall=number(v,6.25,0,100);
  else if(k=="px_wall_push")next.wallPush=number(v,60,0,450);
  else if(k=="eb_ground_range")next.edgeRange=number(v,12,1,64);
  else if(k=="eb_min_fall_speed")next.edgeMinFall=number(v,40,1,1000);
 }
 config=next;enemySnaplines=config.lines;enemyStick=config.stick;enemyDiagnostics=config.debug;localMode=config.local;ebBind=parseBind(config.eb);pxBind=parseBind(config.px);hudBind=parseBind(config.hud);bhopBind=parseBind(config.bhop);assistBind=parseBind(config.assist);reloadBind=parseBind(config.reload);espBind=parseBind(config.esp);aimBind=parseBind(config.aim);
 wantEB=false;wantPX=false;wantAim=false;log(("Config loaded: "+configPath+(config.local?" [LOCAL PHYSICS]":" [INPUT ONLY]")).c_str());
}
static void updateBinds(const unsigned char*k){static bool last[5]{};Bind binds[]={hudBind,bhopBind,assistBind,reloadBind,espBind};for(int i=0;i<5;i++){bool on=held(binds[i],k);if(on&&!last[i]){if(i==0)hud=!hud;else if(i==1)bhop=!bhop;else if(i==2)assists=!assists;else if(i==3)loadConfig();else enemyOverlay=!enemyOverlay;}last[i]=on;}wantEB=assists&&held(ebBind,k);wantPX=assists&&held(pxBind,k);wantAim=config.aimEnabled&&held(aimBind,k);}
struct Contact {bool wall=false,edge=false;Vec normal;};
static Contact contacts(void*p,Vec pos,Vec velocity,Vec mi,Vec ma,bool checkWall,bool checkEdge){
 Contact c;float best=1;
 if(checkWall){for(int i=0;i<8;i++){float a=i*float(M_PI/4);Vec d{cosf(a)*config.wallRange,sinf(a)*config.wallRange,0};auto t=hull(p,pos,pos+d,mi,ma);if(!t.startsolid&&!t.allsolid&&t.fraction<best&&fabsf(t.plane.normal.z)<.15f){best=t.fraction;c.wall=true;c.normal=t.plane.normal;}}}
 if(checkEdge){float reach=std::min(64.f,std::max(config.edgeRange,-velocity.z*dt+2));
  // Ground under only part of the footprint constitutes an edge in synthetic mode.
  for(int step=0;step<2&&!c.edge;step++){Vec q=pos+Vec{velocity.x,velocity.y,0}*(dt*step);int hit=0,miss=0;for(int ix=-1;ix<=1;ix++)for(int iy=-1;iy<=1;iy++){Vec a=q+Vec{ix*std::max(fabsf(mi.x),fabsf(ma.x))*.9f,iy*std::max(fabsf(mi.y),fabsf(ma.y))*.9f,1};auto t=hull(p,a,a+Vec{0,0,-reach-1},{},{ });if(t.startsolid||t.allsolid)continue;if(t.fraction<1&&t.plane.normal.z>.7f)hit++;else if(t.fraction>=1)miss++;}c.edge=hit>0&&miss>0;}
 }
 return c;
}
struct Override {bool px=false,eb=false;Vec velocity;};
static Override chooseOverride(Contact c,Vec v,bool airborne,bool ebHeld,bool pxHeld,bool edgeLatched){Override r;r.velocity=v;if(!airborne)return r;if(pxHeld&&c.wall&&v.z<=0){r.px=true;r.velocity.z=-config.pxFall;float into=r.velocity.dot(c.normal);r.velocity=r.velocity-c.normal*into;}else if(ebHeld&&c.edge&&v.z < -config.edgeMinFall&&!edgeLatched){r.eb=true;r.velocity.z=-gravity*dt*.5f;}return r;}
using Process=void(*)(void*,void*,void*);static Process originalProcess;
// CMoveData::m_vecVelocity at 0x40. Only this layout field is written here.
// The matched CCSGameMovement vtable/entry point is checked before installation.
static void processMovement(void*self,void*p,void*data){
 static void*lastPlayer=nullptr;static bool latched=false;static Vec edgeAt;
 if(!wantEB)latched=false;
 if(!initialized||!data||!p||!config.local||!assists||(!wantEB&&!wantPX)||!call<bool>(engine,26)){originalProcess(self,p,data);return;}
 int index=call<int>(engine,12);if(index<1||index>64||call<void*>(entities,3,index)!=p||get<int>(p,healthOff)<=0||get<unsigned char>(p,waterOff)>=2){originalProcess(self,p,data);return;}
 if(lastPlayer!=p){lastPlayer=p;latched=false;}
 bool ground=get<int>(p,flagsOff)&1;Vec v=get<Vec>(data,64),pos=get<Vec>(p,originOff),mi=get<Vec>(p,minsOff),ma=get<Vec>(p,maxsOff);
 if(!wantEB||ground||(pos.x-edgeAt.x)*(pos.x-edgeAt.x)+(pos.y-edgeAt.y)*(pos.y-edgeAt.y)>24*24)latched=false;
 if(!std::isfinite(v.z)||!std::isfinite(pos.x)||ma.z<20||ma.z>100||ma.x<=0||ma.x>40){originalProcess(self,p,data);return;}
 Contact contact=contacts(p,pos,v,mi,ma,wantPX,wantEB);auto action=chooseOverride(contact,v,!ground,wantEB,wantPX,latched);
 if(action.px&&config.wallPush>0){Vec angle=get<Vec>(data,12);float yaw=angle.y*float(M_PI/180.0);float wx=-contact.normal.x*config.wallPush,wy=-contact.normal.y*config.wallPush;float forward=std::clamp(get<float>(data,44)+cosf(yaw)*wx+sinf(yaw)*wy,-450.f,450.f);float side=std::clamp(get<float>(data,48)+sinf(yaw)*wx-cosf(yaw)*wy,-450.f,450.f);memcpy((char*)data+44,&forward,4);memcpy((char*)data+48,&side,4);}
 if(action.px||action.eb){memcpy((char*)data+64,&action.velocity,sizeof(Vec));if(action.eb){latched=true;edgeAt=pos;}}
 originalProcess(self,p,data);
 // Reapply after the native movement step so its output feeds FinishMove.
 static bool reportedPX=false,reportedEB=false;
 if(action.px&&!reportedPX){reportedPX=true;log("Local PX velocity override reached (not server confirmation).");}
 if(action.eb&&!reportedEB){reportedEB=true;log("Local EB velocity override reached (not server confirmation).");}
 if(action.px||action.eb){Vec out=get<Vec>(data,64);out.z=action.velocity.z;if(action.px){float into=out.dot(contact.normal);out=out-contact.normal*into;localPXStamp=ticks;}else localEBStamp=ticks;memcpy((char*)data+64,&out,sizeof(Vec));}
}
